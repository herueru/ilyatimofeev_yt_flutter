import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart'; 
import 'package:yt_video_search/app/app.dart'; 

class YTVideoSearch extends StatelessWidget { 
  const YTVideoSearch({super.key});

  @override 
  Widget build(BuildContext context) { 
    return BlocProvider(
      create: (context) => AuthBloc(),
      child: MaterialApp.router( 
        title: 'YTVideoSearch', 
        theme: AppTheme.lightTheme, 
        routeInformationProvider: router.routeInformationProvider, 
        routeInformationParser: router.routeInformationParser, 
        routerDelegate: router.routerDelegate, 
        debugShowCheckedModeBanner: false, 
      ),
    );
  } 
} 