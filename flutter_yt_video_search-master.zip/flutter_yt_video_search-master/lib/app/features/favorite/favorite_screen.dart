import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart'; 
import 'package:flutter_bloc/flutter_bloc.dart'; 
import 'package:yt_video_search/app/app.dart';
import 'package:yt_video_search/di/di.dart'; 
import 'package:yt_video_search/domain/domain.dart';
 
class FavoriteScreen extends StatefulWidget { 
  final String userUID;

  const FavoriteScreen({Key? key, required this.userUID}) : super(key: key); 
 
  @override 
  State<FavoriteScreen> createState() => _FavoriteScreenState(); 
} 
 
class _FavoriteScreenState extends State<FavoriteScreen> { 
  final _favoriteBloc = FavoriteBloc(getIt<VideosRepository>());

  @override 
  void initState() {
    _favoriteBloc.add(FavoriteLoad(userUID: widget.userUID)); 
    super.initState();
  }

  @override 
  Widget build(BuildContext context) { 
    return SafeArea( 
      child: Scaffold( 
        appBar: AppBar( 
          title: const Text('Избранное'),
          actions: [
            IconButton(
              icon: const Icon(Icons.close),
              onPressed: () {
                context.go('/home');
              },
            ),
          ],
        ), 
        body: BlocBuilder<FavoriteBloc, FavoriteState>( 
          bloc: _favoriteBloc, 
          builder: (context, state) { 
            if (state is FavoriteLoadInProgress) { 
              return const Center( 
                child: CircularProgressIndicator(), 
              ); 
            }
            if (state is FavoriteLoadSuccess) { 
              List<Video> videos = state.videos; 
 
              return SingleChildScrollView( 
                padding: const EdgeInsets.all(20), 
                child: Column( 
                  crossAxisAlignment: CrossAxisAlignment.start, 
                  children: [
                    ListView.separated( 
                      primary: false, 
                      shrinkWrap: true, 
                      itemCount: videos.length, 
                      itemBuilder: (context, index) { 
                        return ArticleCard( 
                          video: videos[index], 
                        ); 
                      }, 
                      separatorBuilder: (context, index) { 
                        return 20.ph; 
                      }, 
                    ), 
                  ], 
                ), 
              ); 
            } 
 
            if (state is FavoriteLoadFailure) { 
              return ErrorCard( 
                title: 'Ошибка', 
                description: state.exception.toString(), 
                onReload: () { 
                  _favoriteBloc.add(FavoriteLoad(userUID: widget.userUID)); 
                }, 
              ); 
            } 
 
            return const SizedBox(); 
          }, 
        ),
      ), 
    ); 
  } 
} 