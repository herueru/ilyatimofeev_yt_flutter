part of "favorite_bloc.dart"; 
 
sealed class FavoriteEvent extends Equatable { 
  const FavoriteEvent(); 
 
  @override 
  List<Object> get props => []; 
} 
 
class FavoriteLoad extends FavoriteEvent { 
  const FavoriteLoad({required this.userUID, this.completer}); 
 
  final String userUID;
  final Completer? completer; 
 
  @override 
  List<Object> get props => [userUID]; 
} 

class SetArticleFavorite extends FavoriteEvent {
  const SetArticleFavorite({required this.userUID, required this.id, this.completer});

  final String userUID;
  final String id;
  final Completer? completer;

  @override
  List<Object> get props => [id];
}

class ResetArticleFavorite extends FavoriteEvent {
  const ResetArticleFavorite({required this.userUID, required this.id, this.completer});
  
  final String userUID;
  final String id;
  final Completer? completer;
}
