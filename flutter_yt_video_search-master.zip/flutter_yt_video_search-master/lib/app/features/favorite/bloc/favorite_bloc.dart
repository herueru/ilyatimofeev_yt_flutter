import 'dart:async'; 
 
import 'package:equatable/equatable.dart'; 
import 'package:flutter_bloc/flutter_bloc.dart'; 
import 'package:yt_video_search/di/di.dart'; 
import 'package:yt_video_search/domain/domain.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
 
part "favorite_event.dart"; 
part "favorite_state.dart"; 
 
class FavoriteBloc extends Bloc<FavoriteEvent, FavoriteState> { 
  final VideosRepository videosRepository; 
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
 
  FavoriteBloc(this.videosRepository) : super(FavoriteInitial()) { 
    on<FavoriteLoad>(_favoriteLoad);
    on<SetArticleFavorite>(_setFavorite);
    on<ResetArticleFavorite>(_resetFavorite);
  } 
 
  Future<void> _favoriteLoad(event, emit) async { 
    try {
      emit(FavoriteLoadInProgress());

      final snapshot = await _firestore
          .collection('users')
          .doc(event.userUID)
          .collection('videos')
          .get();

      List<Video> videos = [];

      for (var doc in snapshot.docs) {
        final video = await videosRepository.getVideo(doc.id);
        videos.add(video);
      }
      emit(FavoriteLoadSuccess( 
        videos: videos, 
      )); 
    } catch (exception, state) { 
      emit(FavoriteLoadFailure(exception: exception)); 
      talker.handle(exception, state); 
    } finally { 
      event.completer?.complete(); 
    } 
  } 

  Future<void> _setFavorite(SetArticleFavorite event, Emitter<FavoriteState> emit) async {
    try {
      await _firestore
        .collection('users')
        .doc(event.userUID)
        .collection('videos')
        .doc(event.id)
        .set({});
    } catch (exception) {
      emit(ArticleFavoriteLoadFailure(exception: exception));
      talker.handle(exception, StackTrace.current);
    } finally {
      event.completer?.complete();
    }
  }

  Future<void> _resetFavorite(ResetArticleFavorite event, Emitter<FavoriteState> emit) async {
    try {
      await _firestore
        .collection('users')
        .doc(event.userUID)
        .collection('videos')
        .doc(event.id)
        .delete();
    } catch (exception) {
      emit(ArticleFavoriteLoadFailure(exception: exception));
      talker.handle(exception, StackTrace.current);
    } finally {
      event.completer?.complete();
    }
  }

 
  @override 
  void onError(Object error, StackTrace stackTrace) { 
    super.onError(error, stackTrace); 
    talker.handle(error, stackTrace); 
  } 
} 