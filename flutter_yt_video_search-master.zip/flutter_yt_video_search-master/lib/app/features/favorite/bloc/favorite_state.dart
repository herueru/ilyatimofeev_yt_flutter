part of "favorite_bloc.dart"; 
 
sealed class FavoriteState extends Equatable { 
  const FavoriteState(); 
 
  @override 
  List<Object> get props => []; 
} 
 
final class FavoriteInitial extends FavoriteState {} 
 
final class FavoriteLoadInProgress extends FavoriteState {} 
 
final class FavoriteLoadSuccess extends FavoriteState { 
  const FavoriteLoadSuccess({ 
    required this.videos, 
  }); 
 
  final List<Video> videos;
 
  @override 
  List<Object> get props => [videos]; 
} 
 
final class FavoriteLoadFailure extends FavoriteState { 
  const FavoriteLoadFailure({ 
    required this.exception, 
  }); 
 
  final Object? exception; 
 
  @override 
  List<Object> get props => []; 
} 

final class ArticleFavoriteLoadInProgress extends FavoriteState{}

final class ArticleFavoriteLoadSuccess extends FavoriteState{
  const ArticleFavoriteLoadSuccess({ 
    required this.video, 
  }); 
 
  final Video video; 
 
  @override 
  List<Object> get props => [video]; 
}

final class ArticleFavoriteLoadFailure extends FavoriteState { 
  const ArticleFavoriteLoadFailure({ 
      required this.exception, 
    }); 
 
  final Object? exception; 
 
  @override 
  List<Object> get props => []; 
}
