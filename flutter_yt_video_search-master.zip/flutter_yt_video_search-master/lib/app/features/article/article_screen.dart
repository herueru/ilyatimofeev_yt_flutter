import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:yt_video_search/app/app.dart';
import 'package:yt_video_search/di/di.dart';
import 'package:yt_video_search/domain/domain.dart';
 
class ArticleScreen extends StatefulWidget {
  final String videoId;

  const ArticleScreen({Key? key, required this.videoId}) : super(key: key);

  @override 
  State<ArticleScreen> createState() => _ArticleScreenState();
}

 
class _ArticleScreenState extends State<ArticleScreen> {
  final _homeBloc = HomeBloc(getIt<VideosRepository>());
  final _favoriteBloc = FavoriteBloc(getIt<VideosRepository>());

  @override 
  void initState() { 
    _homeBloc.add(ArticleLoad(id: widget.videoId)); 
    super.initState();
  }

  bool _isFavorite = false;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Информация о видео'),
          actions: [
            IconButton(
              icon: Icon(
                _isFavorite ? Icons.favorite : Icons.favorite_border, // меняем иконку в зависимости от состояния
                color: _isFavorite ? Colors.red : Colors.grey, // меняем цвет в зависимости от состояния
              ),
              onPressed: () {
                setState(() {
                  final authState = context.read<AuthBloc>().state;

                  if (authState is AuthAuthenticated) {
                    _isFavorite = !_isFavorite; // переключаем состояние
                    if (_isFavorite) {
                      _favoriteBloc.add(SetArticleFavorite(userUID: authState.uid, id: widget.videoId));
                    }
                    else {
                      _favoriteBloc.add(ResetArticleFavorite(userUID: authState.uid, id: widget.videoId));
                    }
                  }
                });
              },
            ),
          ],
        ),
        body: BlocBuilder<HomeBloc, HomeState>(
          bloc: _homeBloc, 
          builder: (context, state) {
            if (state is ArticleLoadInProgress) { 
              return const Center( 
                child: CircularProgressIndicator(), 
              ); 
            }
            if (state is ArticleLoadSuccess) { 
              Video video = state.video;
              return SingleChildScrollView(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Image.network(video.imageUrl),
                    20.ph,
                    Text(
                      video.title,
                      textAlign: TextAlign.left,
                      style: const TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold
                      )
                    ),
                    20.ph,
                    Text(video.description),
                    20.ph,
                    Text('Дата создания: ${video.publishedAt}'),
                  ],
                ),
              );
            }

            return const SizedBox();
          },
        ),
      ),
    );
  }
}