import 'package:flutter/material.dart'; 
import 'package:flutter_bloc/flutter_bloc.dart'; 
import 'package:yt_video_search/app/app.dart'; 
import 'package:yt_video_search/di/di.dart'; 
import 'package:yt_video_search/domain/domain.dart';
import 'package:go_router/go_router.dart'; 
 
class HomeScreen extends StatefulWidget { 
  const HomeScreen({super.key}); 
 
  @override 
  State<HomeScreen> createState() => _HomeScreenState(); 
} 
 
class _HomeScreenState extends State<HomeScreen> { 
  final _homeBloc = HomeBloc(getIt<VideosRepository>());
  final TextEditingController _controller = TextEditingController();

  @override 
  void initState() { 
    _homeBloc.add(HomeLoad(query: _controller.text)); 
    super.initState(); 
  }

  @override 
  Widget build(BuildContext context) { 
    return SafeArea( 
      child: Scaffold( 
        appBar: AppBar( 
          title: TextField(
            controller: _controller,
            decoration: const InputDecoration(
              hintText: 'Введите текст запроса',
              border: InputBorder.none,
            ),
            style: const TextStyle(color: Colors.white)
          ),
          actions: [
            IconButton(
              icon: const Icon(Icons.search),
              onPressed: () {
                _homeBloc.add(HomeLoad(query: _controller.text)); 
              },
            ),
            IconButton(
              icon: const Icon(Icons.favorite),
              onPressed: () {
                final authState = context.read<AuthBloc>().state;

                if (authState is AuthAuthenticated) {
                  final String uid = authState.uid;
                  context.go('/favorite/$uid');
                } else {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Пожалуйста, войдите в систему.'))
                  );
                }
              },
            ),
            IconButton(
              icon: const Icon(Icons.logout), // Иконка выхода
              onPressed: () async {
                context.read<AuthBloc>().add(AuthSignOutRequested());
                context.go('/login');
              },
            ),
          ],
        ), 
        body: BlocBuilder<HomeBloc, HomeState>( 
          bloc: _homeBloc, 
          builder: (context, state) { 
            if (state is HomeLoadInProgress) { 
              return const Center( 
                child: CircularProgressIndicator(), 
              ); 
            }
            if (state is HomeLoadSuccess) { 
              List<Video> videos = state.videos; 
 
              return SingleChildScrollView( 
                padding: const EdgeInsets.all(20), 
                child: Column( 
                  crossAxisAlignment: CrossAxisAlignment.start, 
                  children: [ 
                    Text( 
                      'Video YouTube', 
                      style: Theme.of(context).textTheme.headlineLarge, 
                    ), 
                    20.ph, 
                    ListView.separated( 
                      primary: false, 
                      shrinkWrap: true, 
                      itemCount: videos.length, 
                      itemBuilder: (context, index) { 
                        return ArticleCard( 
                          video: videos[index], 
                        ); 
                      }, 
                      separatorBuilder: (context, index) { 
                        return 20.ph; 
                      }, 
                    ), 
                  ], 
                ), 
              ); 
            } 
 
            if (state is HomeLoadFailure) { 
              return ErrorCard( 
                title: 'Ошибка', 
                description: state.exception.toString(), 
                onReload: () { 
                  _homeBloc.add(HomeLoad(query: _controller.text)); 
                }, 
              ); 
            } 
 
            return const SizedBox(); 
          }, 
        ), 
      ), 
    ); 
  } 
} 