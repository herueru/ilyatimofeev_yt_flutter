import 'dart:async'; 
 
import 'package:equatable/equatable.dart'; 
import 'package:flutter_bloc/flutter_bloc.dart'; 
import 'package:yt_video_search/di/di.dart'; 
import 'package:yt_video_search/domain/domain.dart'; 
 
part "home_event.dart"; 
part "home_state.dart"; 
 
class HomeBloc extends Bloc<HomeEvent, HomeState> { 
  final VideosRepository videosRepository; 
 
  HomeBloc(this.videosRepository) : super(HomeInitial()) { 
    on<HomeLoad>(_homeLoad);
    on<ArticleLoad>(_articleLoad);
  } 
 
  Future<void> _homeLoad(event, emit) async { 
    try {
      //if (state is! HomeLoadSuccess) { 
        emit(HomeLoadInProgress()); 
      //} 
      final videos = await videosRepository.getAllVideos(event.query); 
      emit(HomeLoadSuccess( 
        videos: videos, 
      )); 
    } catch (exception, state) { 
      emit(HomeLoadFailure(exception: exception)); 
      talker.handle(exception, state); 
    } finally { 
      event.completer?.complete(); 
    } 
  } 

  Future<void> _articleLoad(ArticleLoad event, Emitter<HomeState> emit) async {
    try {
      emit(ArticleLoadInProgress());
      final video = await videosRepository.getVideo(event.id); // метод для получения статьи по ID
      emit(ArticleLoadSuccess(video: video));
    } catch (exception) {
      emit(ArticleLoadFailure(exception: exception));
      talker.handle(exception, StackTrace.current);
    } finally {
      event.completer?.complete();
    }
  }

 
  @override 
  void onError(Object error, StackTrace stackTrace) { 
    super.onError(error, stackTrace); 
    talker.handle(error, stackTrace); 
  } 
} 