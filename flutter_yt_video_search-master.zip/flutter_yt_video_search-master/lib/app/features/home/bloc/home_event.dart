part of "home_bloc.dart"; 
 
sealed class HomeEvent extends Equatable { 
  const HomeEvent(); 
 
  @override 
  List<Object> get props => []; 
} 
 
class HomeLoad extends HomeEvent { 
  const HomeLoad({required this.query, this.completer}); 
 
  final String query;
  final Completer? completer; 
 
  @override 
  List<Object> get props => [query]; 
} 

class ArticleLoad extends HomeEvent {
  const ArticleLoad({required this.id, this.completer});

  final String id; // ID статьи
  final Completer? completer;

  @override
  List<Object> get props => [id];
}
