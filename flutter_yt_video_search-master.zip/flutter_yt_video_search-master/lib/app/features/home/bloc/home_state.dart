part of "home_bloc.dart"; 
 
sealed class HomeState extends Equatable { 
  const HomeState(); 
 
  @override 
  List<Object> get props => []; 
} 
 
final class HomeInitial extends HomeState {} 
 
final class HomeLoadInProgress extends HomeState {} 
 
final class HomeLoadSuccess extends HomeState { 
  const HomeLoadSuccess({ 
    required this.videos, 
  }); 
 
  final List<Video> videos;
 
  @override 
  List<Object> get props => [videos]; 
} 
 
final class HomeLoadFailure extends HomeState { 
  const HomeLoadFailure({ 
    required this.exception, 
  }); 
 
  final Object? exception; 
 
  @override 
  List<Object> get props => []; 
} 

final class ArticleLoadInProgress extends HomeState{}

final class ArticleLoadSuccess extends HomeState{
  const ArticleLoadSuccess({ 
    required this.video, 
  }); 
 
  final Video video; 
 
  @override 
  List<Object> get props => [video]; 
}

final class ArticleLoadFailure extends HomeState { 
  const ArticleLoadFailure({ 
      required this.exception, 
    }); 
 
  final Object? exception; 
 
  @override 
  List<Object> get props => []; 
}
