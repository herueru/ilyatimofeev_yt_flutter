import 'package:flutter/material.dart'; 
import 'package:go_router/go_router.dart'; 
import 'package:talker_flutter/talker_flutter.dart'; 
 
import 'package:yt_video_search/app/app.dart';
import 'package:yt_video_search/di/di.dart';
 
final GlobalKey<NavigatorState> _rootNavigationKey = GlobalKey<NavigatorState>( 
  debugLabel: 'root', 
); 
 
final GoRouter router = GoRouter( 
  debugLogDiagnostics: true, 
  observers: [TalkerRouteObserver(talker)], 
  initialLocation: '/login', 
  navigatorKey: _rootNavigationKey, 
  routes: <RouteBase>[
    GoRoute(
      path: '/login', // маршрут для экрана входа
      pageBuilder: (context, state) {
        return NoTransitionPage<void>(
          key: state.pageKey,
          child: LoginScreen(), // Ваша реализация LoginPage
        );
      },
    ),
    GoRoute( // маршрут для экрана регистрации
      path: '/register',
      pageBuilder: (context, state) {
        return NoTransitionPage<void>(
          key: state.pageKey,
          child: RegisterScreen(), // Ваша реализация RegistrationPage
        );
      },
    ),
    GoRoute( 
      path: '/home', 
      pageBuilder: (context, state) { 
        return NoTransitionPage<void>( 
          key: state.pageKey, 
          child: const HomeScreen(), 
        ); 
      },
      routes: [ 
        GoRoute( 
          path: 'article/:id', 
          pageBuilder: (context, state) { 
            final articleId = state.pathParameters['id']!;
            return NoTransitionPage( 
              key: state.pageKey, 
              child: ArticleScreen(videoId: articleId), 
            ); 
          }, 
        ),
      ], 
    ),
    GoRoute( 
      path: '/favorite/:uid',
      pageBuilder: (context, state) { 
        final String uid = state.pathParameters['uid']!;
        return NoTransitionPage<void>( 
          key: state.pageKey, 
          child: FavoriteScreen(userUID: uid,), 
        ); 
      }, 
    ),
  ], 
); 