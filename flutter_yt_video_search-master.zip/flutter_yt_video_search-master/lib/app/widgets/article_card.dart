import 'package:flutter/material.dart'; 
import 'package:go_router/go_router.dart'; 
import 'package:yt_video_search/app/app.dart'; 
import 'package:yt_video_search/domain/domain.dart';


class ArticleCard extends StatelessWidget { 
  final Video video;
  
  const ArticleCard({ 
    super.key, 
    required this.video
  }); 
 
  @override 
  Widget build(BuildContext context) {
    return InkWell( 
      onTap: () {
        context.go('/home/article/${video.id}'); 
      }, 
      borderRadius: BorderRadius.circular(5), 
      child: Row( 
        crossAxisAlignment: CrossAxisAlignment.start, 
        children: [ 
          ClipRRect( 
            borderRadius: BorderRadius.circular(10), 
            child: Image.network( 
              width: 100, 
              height: 100, 
              video.imageUrl, 
              fit: BoxFit.cover, 
            ), 
          ), 
          20.pw, 
          Expanded( 
            child: Column( 
              crossAxisAlignment: CrossAxisAlignment.start, 
              children: [ 
                Text( 
                  video.title, 
                  maxLines: 1, 
                  overflow: TextOverflow.ellipsis, 
                  style: Theme.of(context).textTheme.titleLarge, 
                ), 
                5.ph, 
                Text( 
                  video.description, 
                  maxLines: 4, 
                  overflow: TextOverflow.ellipsis, 
                  style: Theme.of(context).textTheme.bodyLarge, 
                ), 
              ], 
            ), 
          ), 
        ], 
      ), 
    ); 
  } 
} 