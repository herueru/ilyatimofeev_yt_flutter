import 'dart:async';
import 'package:yt_video_search/domain/domain.dart';

abstract class VideosRepositoryIterface { 
  Future<List<Video>> getAllVideos(String query); 
  Future<Video> getVideo(String id);
} 
