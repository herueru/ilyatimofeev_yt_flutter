import 'dart:async'; 
 
import 'package:dio/dio.dart'; 
import 'package:yt_video_search/data/data.dart';
import 'package:yt_video_search/domain/domain.dart'; 

class VideosRepository extends VideosRepositoryIterface { 
  VideosRepository({required this.dio}); 
 
  final Dio dio;
 
  @override 
  Future<List<Video>> getAllVideos(String query) async { 
    try {
      final Response response = await dio.get(
        Endpoints.getAllVideos,
        queryParameters: {
          'q': query,
          'type': 'video'
        }
      );
      final videos = (response.data['items'] as List) 
          .map((e) => Video.fromJsonList(e)) 
          .toList();
      return videos; 
    } on DioException catch (e) { 
      throw e.message.toString(); 
    } 
  } 

  @override
  Future<Video> getVideo(String id) async {
    try {
      final Response response = await dio.get(
        Endpoints.getOneVideo,
        queryParameters: {
          'id': id,
        }
      );
      final video = (response.data['items'] as List) 
          .map((e) => Video.fromJsonObj(e)) 
          .toList();
      return video[0];
    } on DioException catch (e) { 
      throw e.message.toString(); 
    } 
  }
} 
