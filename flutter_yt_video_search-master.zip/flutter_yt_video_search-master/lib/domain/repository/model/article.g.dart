// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'article.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

Video _$VideoFromJsonList(Map<String, dynamic> json) => Video(
      id: json['id']['videoId'] as String,
      publishedAt: json['snippet']['publishedAt'] as String,
      channelId: json['snippet']['channelId'] as String,
      title: json['snippet']['title'] as String,
      description: json['snippet']['description'] as String,
      imageUrl: json['snippet']['thumbnails']['high']['url'] as String,
      channelTitle: json['snippet']['channelTitle'] as String,
    );

Video _$VideoFromJsonObj(Map<String, dynamic> json) => Video(
      id: json['id'] as String,
      publishedAt: json['snippet']['publishedAt'] as String,
      channelId: json['snippet']['channelId'] as String,
      title: json['snippet']['title'] as String,
      description: json['snippet']['description'] as String,
      imageUrl: json['snippet']['thumbnails']['maxres']['url'] as String,
      channelTitle: json['snippet']['channelTitle'] as String,
    );

Map<String, dynamic> _$VideoToJson(Video instance) => <String, dynamic>{
      'id': instance.id,
      'publishedAt': instance.publishedAt,
      'channelId': instance.channelId,
      'title': instance.title,
      'description': instance.description,
      'imageUrl': instance.imageUrl,
      'channelTitle': instance.channelTitle,
    };
