import 'package:json_annotation/json_annotation.dart'; 

part 'article.g.dart'; 

@JsonSerializable() 
class Video { 
  Video({ 
    required this.id,
    required this.publishedAt,
    required this.channelId,
    required this.title,
    required this.description,
    required this.imageUrl,
    required this.channelTitle
  }); 
 
  final String id;
  final String publishedAt;
  final String channelId;
  final String title;
  final String description;
  final String imageUrl;
  final String channelTitle;
 
  factory Video.fromJsonList(Map<String, dynamic> json) => _$VideoFromJsonList(json); 
  factory Video.fromJsonObj(Map<String, dynamic> json) => _$VideoFromJsonObj(json); 
 
  Map<String, dynamic> toJson() => _$VideoToJson(this); 
}
