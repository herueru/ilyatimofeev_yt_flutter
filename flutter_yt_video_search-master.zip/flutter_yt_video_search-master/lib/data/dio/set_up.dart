import 'package:talker_dio_logger/talker_dio_logger.dart'; 
import 'package:dio/dio.dart';
import 'package:yt_video_search/di/di.dart';

void setUpDio() { 
  getIt<Dio>().options.baseUrl = 'https://www.googleapis.com/youtube/v3/';
  getIt<Dio>().options.queryParameters.addAll({ 
    'part': 'snippet',
    'key': 'AIzaSyDKNA6x_y7mkkUm2xuni3ySgM1XDQ0Zg3w',
  });
  getIt<Dio>().options.connectTimeout = const Duration(minutes: 1); 
  getIt<Dio>().options.receiveTimeout = const Duration(minutes: 1); 
  getIt<Dio>().interceptors.addAll(
    [ 
      TalkerDioLogger( 
        talker: talker, 
        settings: const TalkerDioLoggerSettings( 
          printRequestData: true, 
          printRequestHeaders: true, 
        ), 
      ), 
    ]
  ); 
} 
