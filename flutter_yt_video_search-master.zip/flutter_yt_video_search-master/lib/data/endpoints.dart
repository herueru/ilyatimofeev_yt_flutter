class Endpoints {
  Endpoints._();

  static const String getAllVideos = 'search';
  static const String getOneVideo = 'videos';
}
