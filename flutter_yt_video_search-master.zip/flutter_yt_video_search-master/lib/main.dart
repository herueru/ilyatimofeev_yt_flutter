import 'package:flutter/material.dart'; 
import 'package:yt_video_search/di/di.dart'; 
import 'package:yt_video_search/yt_video_search.dart';
import 'package:firebase_core/firebase_core.dart'; 
import 'firebase_options.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  setupLocator();
  FlutterError.onError = (details) => talker.handle( 
    details.exception, 
    details.stack, 
  ); 
  runApp(const YTVideoSearch()); 
} 