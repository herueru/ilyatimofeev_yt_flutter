import 'package:dio/dio.dart';
import 'package:get_it/get_it.dart'; 
import 'package:talker_flutter/talker_flutter.dart';
import 'package:yt_video_search/data/data.dart';
import 'package:yt_video_search/domain/domain.dart';
import 'package:yt_video_search/app/app.dart'; 

final getIt = GetIt.instance; 
final talker = TalkerFlutter.init();
final Dio dio = Dio();

Future<void> setupLocator() async { 
  getIt.registerSingleton<Dio>(Dio());
  setUpDio();
  getIt.registerSingleton(talker);
  getIt.registerSingleton(VideosRepository(dio: getIt<Dio>())); 
  getIt.registerSingleton(HomeBloc(getIt.get<VideosRepository>()));
} 
