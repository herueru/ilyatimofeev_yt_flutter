package com.example.yt_video_search

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
